# Simulador ProBatch AI · Evaluá tu operación batch

Simulador de un turno noche de cierre bancario para decisores (Operaciones, Tecnología, Core, RPA, Riesgo).
Al final genera un informe con el impacto estimado y captura el lead.

## Archivos
- `index.html` → el simulador (página principal).
- `Code.gs` → backend en Google Apps Script: guarda visitas y leads en Google Sheets y avisa por mail.
- `videos/` → videos de ProBatch AI (MP4, 1920×1080, con subtítulos).

## Configuración (una sola vez)
1. Crear una Google Sheet → Extensiones → Apps Script → pegar `Code.gs` → ejecutar `prueba` y aceptar permisos.
2. Implementar → Nueva implementación → Aplicación web · Ejecutar como: Yo · Acceso: Cualquier usuario → copiar la URL `/exec`.
3. En `index.html`, pegar esa URL en `const LEAD_ENDPOINT = '';` (y cambiar `FEEDBACK_EMAIL` si corresponde).

## Links personalizados por cuenta
`https://enmanueltolosa.com/probatch-simulador/?banco=Banco%20Ejemplo&rol=cio&core=cobis`
- `rol`: ops · cio · core · rpa · cfo
- `core`: cobis (o topaz) · bantotal · temenos · otro

Datos ilustrativos. Las capacidades de ProBatch AI describen la dirección de producto y están en definición de requisitos.
